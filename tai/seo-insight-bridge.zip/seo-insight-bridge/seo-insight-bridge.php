<?php
/**
 * Plugin Name: SEO Insight Bridge
 * Description: Cho phần mềm SEOtukhoa Studio đọc và sửa tiêu đề SEO, mô tả, dữ liệu có cấu trúc qua REST API. Chỉ tài khoản có quyền sửa bài (đăng nhập bằng Mật khẩu ứng dụng) mới dùng được.
 * Version: 1.0.1
 * Requires at least: 5.6
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SIB_VERSION', '1.0.1');
define('SIB_JSON_FLAGS', JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);

/** Nhận biết plugin SEO đang dùng để ghi đúng chỗ. */
function sib_seo_plugin() {
    if (defined('WPSEO_VERSION')) {
        return 'yoast';
    }
    if (class_exists('RankMath')) {
        return 'rankmath';
    }
    if (defined('SEOPRESS_VERSION')) {
        return 'seopress';
    }
    return 'bridge';
}

function sib_meta_keys($plugin) {
    switch ($plugin) {
        case 'yoast':
            return array('_yoast_wpseo_title', '_yoast_wpseo_metadesc');
        case 'rankmath':
            return array('rank_math_title', 'rank_math_description');
        case 'seopress':
            return array('_seopress_titles_title', '_seopress_titles_desc');
        default:
            return array('_sib_title', '_sib_description');
    }
}

function sib_can_edit_posts() {
    return current_user_can('edit_posts');
}

function sib_can_edit($request) {
    $id = (int) $request['id'];
    return $id > 0 && get_post($id) && current_user_can('edit_post', $id);
}

function sib_seo_response($id) {
    $plugin = sib_seo_plugin();
    list($title_key, $desc_key) = sib_meta_keys($plugin);
    return array(
        'id' => $id,
        'plugin' => $plugin,
        'title' => (string) get_post_meta($id, $title_key, true),
        'description' => (string) get_post_meta($id, $desc_key, true),
        'post_title' => get_the_title($id),
    );
}

add_action('rest_api_init', function () {
    register_rest_route('seo-insight/v1', '/status', array(
        'methods' => 'GET',
        'permission_callback' => 'sib_can_edit_posts',
        'callback' => function () {
            return array('version' => SIB_VERSION, 'seo_plugin' => sib_seo_plugin());
        },
    ));

    register_rest_route('seo-insight/v1', '/resolve', array(
        'methods' => 'GET',
        'permission_callback' => 'sib_can_edit_posts',
        'args' => array('url' => array('required' => true, 'type' => 'string')),
        'callback' => function ($request) {
            $url = esc_url_raw((string) $request['url']);
            $id = url_to_postid($url);
            $front = (int) get_option('page_on_front');
            if (!$id && $front && untrailingslashit($url) === untrailingslashit(home_url())) {
                $id = $front;
            }
            if (!$id) {
                return new WP_Error('sib_not_found', 'Không tìm thấy bài viết hoặc trang cho đường dẫn này.', array('status' => 404));
            }
            $type = get_post_type($id);
            $obj = get_post_type_object($type);
            return array(
                'id' => $id,
                'type' => $type,
                'rest_base' => ($obj && !empty($obj->rest_base)) ? $obj->rest_base : $type,
                'is_front' => $front === $id,
                'can_edit' => current_user_can('edit_post', $id),
            );
        },
    ));

    register_rest_route('seo-insight/v1', '/seo/(?P<id>\d+)', array(
        array(
            'methods' => 'GET',
            'permission_callback' => 'sib_can_edit',
            'callback' => function ($request) {
                return sib_seo_response((int) $request['id']);
            },
        ),
        array(
            'methods' => 'POST',
            'permission_callback' => 'sib_can_edit',
            'callback' => function ($request) {
                $id = (int) $request['id'];
                list($title_key, $desc_key) = sib_meta_keys(sib_seo_plugin());
                if ($request->has_param('title')) {
                    update_post_meta($id, $title_key, wp_slash(sanitize_text_field((string) $request['title'])));
                }
                if ($request->has_param('description')) {
                    update_post_meta($id, $desc_key, wp_slash(sanitize_text_field((string) $request['description'])));
                }
                clean_post_cache($id);
                return sib_seo_response($id);
            },
        ),
    ));

    register_rest_route('seo-insight/v1', '/schema/(?P<id>\d+)', array(
        array(
            'methods' => 'GET',
            'permission_callback' => 'sib_can_edit',
            'callback' => function ($request) {
                return array('jsonld' => (string) get_post_meta((int) $request['id'], '_sib_schema', true));
            },
        ),
        array(
            'methods' => 'POST',
            'permission_callback' => 'sib_can_edit',
            'callback' => function ($request) {
                $id = (int) $request['id'];
                $raw = (string) $request['jsonld'];
                if ($raw === '') {
                    delete_post_meta($id, '_sib_schema');
                    return array('jsonld' => '');
                }
                $data = json_decode($raw, true);
                if (!is_array($data)) {
                    return new WP_Error('sib_bad_json', 'Dữ liệu có cấu trúc không phải JSON hợp lệ.', array('status' => 400));
                }
                $json = wp_json_encode($data, SIB_JSON_FLAGS);
                update_post_meta($id, '_sib_schema', wp_slash($json));
                return array('jsonld' => $json);
            },
        ),
    ));
});

/* Khi website không dùng Yoast, Rank Math hay SEOPress, plugin này tự in tiêu đề và mô tả đã lưu. */
add_filter('pre_get_document_title', function ($title) {
    if (sib_seo_plugin() !== 'bridge' || !is_singular()) {
        return $title;
    }
    $custom = (string) get_post_meta(get_queried_object_id(), '_sib_title', true);
    return $custom !== '' ? $custom : $title;
}, 20);

add_action('wp_head', function () {
    if (!is_singular()) {
        return;
    }
    $id = get_queried_object_id();
    if (sib_seo_plugin() === 'bridge') {
        $desc = (string) get_post_meta($id, '_sib_description', true);
        if ($desc !== '') {
            echo '<meta name="description" content="' . esc_attr($desc) . '" />' . "\n";
        }
    }
    $schema = (string) get_post_meta($id, '_sib_schema', true);
    if ($schema !== '') {
        $data = json_decode($schema, true);
        if (is_array($data)) {
            // Thoát "<", ">", "&" thành \u003C... và giữ thoát "/", nên nội dung không thể đóng hay phá thẻ <script>
            echo '<script type="application/ld+json">' . wp_json_encode($data, SIB_JSON_FLAGS) . '</script>' . "\n";
        }
    }
}, 5);
